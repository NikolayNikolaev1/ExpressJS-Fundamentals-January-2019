const mongoose = require('mongoose');
const { Schema } = mongoose;

const rentSchema = new Schema({
    days: { type: Schema.Types.Number, required: true },
    car: { type: Schema.Types.ObjectId, ref: 'Car', required: true },
    owner: { type: Schema.Types.ObjectId, ref: 'User', required: true }
});

const Rent = mongoose.model('Rent', rentSchema);

module.exports = Rent;